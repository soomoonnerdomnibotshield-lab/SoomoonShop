const admins = [
    { user: "SoomoonNerProfessor", pass: "Soomoon22" },
    { user: "Senhordosaneis588", pass: "Senhor55" },
];

function doLogin() {
    let u = document.getElementById("user").value;
    let p = document.getElementById("pass").value;
    let msg = document.getElementById("loginStatus");

    let isAdmin = admins.some(a => a.user === u && a.pass === p);

    if (!u || !p) {
        msg.innerHTML = "Preencha todos os campos.";
        return;
    }

    if (isAdmin) {
        msg.innerHTML = "✔ Admin logado!";
    } else {
        msg.innerHTML = "✔ Jogador logado!";
    }

    document.getElementById("loginArea").style.display = "none";
    document.getElementById("gameArea").style.display = "block";
}

/* AVISO DE MODO DEITADO */
window.addEventListener("orientationchange", () => {
    console.log("Orientação mudada");
});